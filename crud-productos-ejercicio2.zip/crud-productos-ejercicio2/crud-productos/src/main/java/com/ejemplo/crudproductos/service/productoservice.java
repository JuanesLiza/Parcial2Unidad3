package com.ejemplo.crudproductos.service;
import com.ejemplo.crudproductos.model.producto;
import com.ejemplo.crudproductos.repositorio.productorepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class productoservice {
    private final productorepository repository;

    public productoservice(productorepository repository) {
        this.repository = repository;
    }

    public List<producto> obtenerTodos() {
        return repository.findAll();
    }

    public producto obtenerPorId(String id) {
        return repository.findById(id);
    }

    public producto agregar(producto producto) {
        return repository.save(producto);
    }

    public producto actualizar(String id, producto producto) {
        producto.setId(id);
        return repository.save(producto);
    }
    public void eliminar(String id) {
        repository.delete(id);
    }
}