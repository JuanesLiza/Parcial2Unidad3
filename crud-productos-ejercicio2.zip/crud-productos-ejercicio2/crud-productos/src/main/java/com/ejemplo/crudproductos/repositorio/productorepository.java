package com.ejemplo.crudproductos.repositorio;
import com.ejemplo.crudproductos.model.producto;
import org.springframework.stereotype.Repository;

import java.util.*;
@Repository
public class productorepository {
    private final Map<String, producto> productos = new HashMap<>();

    public List<producto> findAll() {
        return new ArrayList<>(productos.values());
    }

    public producto findById(String id) {
        return productos.get(id);
    }

    public producto save(producto producto) {
        productos.put(producto.getId(), producto);
        return producto;
    }

    public void delete(String id) {
        productos.remove(id);
    }
}
