package com.ejemplo.crudproductos.controller;
import com.ejemplo.crudproductos.model.producto;
import com.ejemplo.crudproductos.service.productoservice;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/productos")
public class ProductoController {
    private final productoservice service;

    public ProductoController(productoservice service) {
        this.service = service;
    }
    @PostMapping
    public producto agregarProducto(@RequestBody producto producto) {
        return service.agregar(producto);
    }

    @GetMapping
    public List<producto> obtenerProductos() {
        return service.obtenerTodos();
    }

    @GetMapping("/{id}")
    public producto obtenerProducto(@PathVariable String id) {
        return service.obtenerPorId(id);
    }

    @PutMapping("/{id}")
    public producto actualizarProducto(@PathVariable String id, @RequestBody producto producto) {
        return service.actualizar(id, producto);
    }

    @DeleteMapping("/{id}")
    public void eliminarProducto(@PathVariable String id) {
        service.eliminar(id);
    }
}