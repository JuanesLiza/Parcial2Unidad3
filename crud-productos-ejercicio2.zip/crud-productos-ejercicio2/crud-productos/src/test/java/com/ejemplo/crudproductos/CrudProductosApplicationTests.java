package com.ejemplo.crudproductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
