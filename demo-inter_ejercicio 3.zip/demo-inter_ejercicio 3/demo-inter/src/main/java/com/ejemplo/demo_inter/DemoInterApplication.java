package com.ejemplo.demo_inter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoInterApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoInterApplication.class, args);
	}

}
