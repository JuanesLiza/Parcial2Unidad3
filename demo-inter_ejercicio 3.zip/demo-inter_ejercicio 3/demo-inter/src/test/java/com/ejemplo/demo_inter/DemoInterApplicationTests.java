package com.ejemplo.demo_inter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoInterApplicationTests {

	@Test
	void contextLoads() {
	}

}
