package com.ejemplo.webflux_productos.controller;

import com.ejemplo.webflux_productos.model.producto;
import org.testng.annotations.Test;
import org.springframework.boot.test.context.SpringBootTest;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@SpringBootTest
public class ProductoControllerTest {
    private final Controladorwebflux productoController = new Controladorwebflux();

    @Test
    public void testListaProductos() {
        Flux<producto> productos = productoController.listarProductos();

        StepVerifier.create(productos)
                .expectNextMatches(p -> p.getNombre().equals("Laptop"))
                .expectNextMatches(p -> p.getNombre().equals("Mouse"))
                .expectNextMatches(p -> p.getNombre().equals("Teclado"))
                .verifyComplete();
    }
}
