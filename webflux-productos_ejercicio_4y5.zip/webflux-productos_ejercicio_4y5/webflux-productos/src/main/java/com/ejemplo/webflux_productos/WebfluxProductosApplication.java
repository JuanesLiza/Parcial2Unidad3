package com.ejemplo.webflux_productos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxProductosApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxProductosApplication.class, args);
	}

}
