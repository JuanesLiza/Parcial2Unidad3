package com.ejemplo.webflux_productos.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class producto {
    private String id;
    private String nombre;
    private Double precio;
}
