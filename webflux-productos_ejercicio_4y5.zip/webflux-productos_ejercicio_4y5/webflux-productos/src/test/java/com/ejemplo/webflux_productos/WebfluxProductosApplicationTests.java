package com.ejemplo.webflux_productos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
